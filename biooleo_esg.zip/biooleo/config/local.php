<?php
return [
    'DB_HOST'    => '127.0.0.1',
    'DB_PORT'    => 3308,
    'DB_NAME'    => 'biooleo_esg',
    'DB_USER'    => 'admin',
    'DB_PASS'    => '1234',

    'APP_SECRET' => 'naoseiqualfrasecolocar',

    'GOOGLE_CLIENT_ID'     => '978977960782-jhq22dn51c1ka48nlu97kjn47g57tn9l.apps.googleusercontent.com',
    'GOOGLE_CLIENT_SECRET' => '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',
    'GOOGLE_REDIRECT_URI'  => 'http://localhost/biooleo/google-callback.php',

    'DEPURACAO'  => true,
];
